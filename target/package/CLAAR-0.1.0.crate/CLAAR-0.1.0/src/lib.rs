//This is a library for drawing triangles in the terminal
//Use Renderer::init() to build the "screen" (warning that this makes outputting from the terminal pretty much unusable)
//Use point or triangle's draw method to add stuff to the framebuffer

//Modules needed for drawing
pub mod framebuffer;
pub mod primatives;
